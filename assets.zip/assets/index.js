export { default as HeroImage } from "./hero.png";
export { default as Avatar } from "./avatar.png";
export { default as Hotels } from "./hotel.png";
export { default as Attractions } from "./attraction.png";
export { default as Restaurants } from "./restaurants.png";
export { default as NotFound } from "./NotFound.png";
